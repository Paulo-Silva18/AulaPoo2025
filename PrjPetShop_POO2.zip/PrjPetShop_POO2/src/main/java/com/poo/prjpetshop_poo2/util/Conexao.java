/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjpetshop_poo2.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author IFTM
 */
public class Conexao {
    final private String driver = "org.postgresql.Driver";
    final private String url = "jdbc:postgresql://localhost:5432" + "/bd_petshop";
    
    final private String usuario = "postgres";
    final private String senha = "postgres";
    
    public Connection conectar() throws SQLException{
        Connection conn = null;
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url, usuario, senha);
        }
        catch(ClassNotFoundException ex){
            ex.printStackTrace();
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return conn;
    }
    
    
}
