/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.poo.prjpetshop_poo2.dao;

import com.poo.prjpetshop_poo2.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author IFTM
 */
public class PessoaDAO {
    Connection conn;
    
    public PessoaDAO() throws SQLException {
        conn = new Conexao().conectar();
    }
    public Pessoa salvar(Pessoa p) {
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pessoa(nome, cpf, data_nascimento) values(?,?,?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.setString(3, p.getData_nasc());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()){
                p.setIdpessoa(rs.getInt("idpessoa"));
            }
            else{
                p.setIdpessoa(-1);
            }
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
        return p;
    }
}
