/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Objetos.Pet;
import Util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paulo Henrique
 */
public class PetDAO {
    Connection conn;
    PessoaDAO pDAO;
    public PetDAO() {
        conn = new Conexao().conectar();
        pDAO = new PessoaDAO();
    }
    
    public Pet salvar(Pet pet) {
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pet(nome, raca, data_nascimento, cor, porte, idpessoa) values(?, ?, ?, ?, ?, ?)" , Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, pet.getNome());
            stmt.setString(2, pet.getRaca());
            stmt.setString(3, pet.getData_nasc());
            stmt.setString(4, pet.getCor());
            stmt.setString(5, pet.getPorte());
            stmt.setInt(6, pet.getPessoa().getIdpessoa());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            if(rs.next()) {
                pet.setIdpet(rs.getInt("idpet"));
            }
            else {
                pet.setIdpet(-1);
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return pet;
    }
    
    public void editar(Pet pet){
        try{
            PreparedStatement stmt = conn.prepareStatement("UPDATE pet SET nome = ?, data_nascimento = ? cor = ?, porte = ?, idpessoa = ? WHERE idpet = ?");
            stmt.setString(1, pet.getNome());
            stmt.setString(2, pet.getRaca());
            stmt.setString(3, pet.getData_nasc());
            stmt.setString(4, pet.getCor());
            stmt.setString(5, pet.getPorte());
            stmt.setInt(6, pet.getPessoa().getIdpessoa());
            stmt.setInt(7, pet.getIdpet());
            stmt.executeUpdate();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    public int excluir(Pet pet) {
        int verif = 0;
        try{
            PreparedStatement stmt = conn.prepareStatement("DELETE FROM pet WHERE idpet = ?");
            stmt.setInt(1, pet.getIdpet());
            verif = stmt.executeUpdate();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return verif;
    }
    
    public List<Pet> getPets(Pet pet){
        List<Pet> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pet");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pet> getPets(){
        List<Pet> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pet");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pet> getPets(String nome){
        List<Pet> lstP = new ArrayList<>();
        ResultSet rs;
        
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pet WHERE nome ILIKE ?");
            ppStmt.setString(1, nome+ "%");
            rs = ppStmt.executeQuery();
            while(rs.next()){
                lstP.add(getPet(rs));
            }
            
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public Pet getPets(int idpet) {
        Pet pet = new Pet();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pet WHERE idpet = ?", ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ppStmt.setInt(1, idpet);
            rs = ppStmt.executeQuery();
            rs.first();
            pet = getPet(rs);
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return pet;
    }
    
    public List<Pet> getPets(String nome, String dataInicio, String dataFim){
        List<Pet> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pet WHERE nome ILIKE ? AND " + "data_nascimento BETWEEN ? AND ?");
            ppStmt.setString(1, nome+ "%");
            ppStmt.setString(2, dataInicio);
            ppStmt.setString(3, dataFim);
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public List<Pet> getPets(String dataInicio, String dataFim){
        List<Pet> lstP = new ArrayList<>();
        ResultSet rs;
        try{
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM pet WHERE data_nascimento " + "BETWEEN ? AND ?");
            ppStmt.setString(1, dataInicio);
            ppStmt.setString(2, dataFim);
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstP.add(getPet(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
    }
    
    public Pet getPet(ResultSet rs) throws SQLException {
        Pet pet = new Pet();
        pet.setIdpet(rs.getInt("idpet"));
        pet.setNome(rs.getString("nome"));
        pet.setRaca(rs.getString("raca"));
        pet.setData_nasc(rs.getString("data_nascimento"));
        pet.setCor(rs.getString("cor"));
        pet.setPorte(rs.getString("porte"));
        pet.setPessoa(pDAO.getPessoas(rs.getInt("idpessoa")));
     
        return pet;
    }
}
