package com.mycompany.biblioteca;
import executable.LibrarySystem2;
import entities.Usuarios;
import entities.Livros;
import entities.Emprestimos;
import database.LibraryDatabase;
import java.sql.Timestamp;

/**
 *
 * @author Paulo Henrique
 */
public class Biblioteca {

    public static void main(String[] args) {
        
    }
}
