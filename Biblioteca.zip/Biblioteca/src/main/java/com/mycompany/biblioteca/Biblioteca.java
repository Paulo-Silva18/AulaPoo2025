package com.mycompany.biblioteca;
import executable.LibrarySystem2;
import entities.Usuarios;
import entities.Livros;
import entities.Emprestimos;
import database.LibraryDatabase;
import java.sql.Timestamp;

/**
 *
 * @author Paulo Henrique
 */
public class Biblioteca {

    public static void main(String[] args) {
        // Instancia o componente do banco de dados
        LibraryDatabase db = new LibraryDatabase();
        db.connect();
        db.limparTabelas(); 

        // Instancia o componente executável
        LibrarySystem2 librarySystem = new LibrarySystem2();

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Usuarios usuarioTeste = new Usuarios(0, "João", "joao" + timestamp.getTime() + "@email.com");
        Livros livroTeste = new Livros(0, "A Jornada do Herói", "Joseph Campbell", 1949);

        System.out.println("\n--- Gerenciando Usuários ---");
        int idUsuarioGerado = librarySystem.adicionarUsuario(usuarioTeste);
        // ADICIONE ESTA LINHA:
        System.out.println("ID do usuário gerado: " + idUsuarioGerado);
        Usuarios foundUser = librarySystem.buscarUsuario(idUsuarioGerado);
        System.out.println("Usuário encontrado no banco: " + (foundUser != null ? foundUser.getNome() : "Nenhum"));

        System.out.println("\n--- Gerenciando Livros ---");
        int idLivroGerado = librarySystem.adicionarLivro(livroTeste);
        // ADICIONE ESTA LINHA:
        System.out.println("ID do livro gerado: " + idLivroGerado);
        Livros foundBook = librarySystem.buscarLivro(idLivroGerado);
        System.out.println("Livro encontrado no banco: " + (foundBook != null ? foundBook.getTitulo() : "Nenhum"));

        // --- Gerenciando Empréstimos ---
        // Crie o Empréstimo com os IDs gerados
        Emprestimos emprestimo = new Emprestimos(idLivroGerado, idUsuarioGerado);
        
        System.out.println("\n--- Realizando Empréstimo ---");
        librarySystem.realizarEmprestimo(emprestimo);
    }
}
