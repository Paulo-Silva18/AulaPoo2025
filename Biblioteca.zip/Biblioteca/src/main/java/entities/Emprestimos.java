/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

public class Emprestimos {
    private int id;
    private int idLivro;
    private int idUsuario;

    // Construtor antigo
    public Emprestimos(int id, int idLivro, int idUsuario) {
        this.id = id;
        this.idLivro = idLivro;
        this.idUsuario = idUsuario;
    }
    
    // NOVO CONSTRUTOR para ser usado quando o ID é gerado pelo banco
    public Emprestimos(int idLivro, int idUsuario) {
        this.idLivro = idLivro;
        this.idUsuario = idUsuario;
    }

    // Getters
    public int getId() {
        return id;
    }

    public int getIdLivro() {
        return idLivro;
    }

    public int getIdUsuario() {
        return idUsuario;
    }
}
