/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package executable;

import interfaces.FazerEmprestimo;
import interfaces.GerenciarLivro;
import entities.Livros;
import entities.Usuarios;
import entities.Emprestimos;
import interfaces.GerenciarUsuario;
import services.UsuarioService;
import services.LivroService;
import services.EmprestimoService;

public class LibrarySystem2 implements GerenciarUsuario, GerenciarLivro, FazerEmprestimo {

    private UsuarioService usuarioService;
    private LivroService livroService;
    private EmprestimoService emprestimoService;
    
    public LibrarySystem2() {
        this.usuarioService = new UsuarioService();
        this.livroService = new LivroService();
        this.emprestimoService = new EmprestimoService();
    }

    @Override
    public int adicionarUsuario(Usuarios usuario) {
        return usuarioService.adicionarUsuario(usuario);
    }
    
    @Override
    public int adicionarLivro(Livros livro) {
        return livroService.adicionarLivro(livro);
    }

    @Override
    public void removerUsuario(int id) {
        usuarioService.removerUsuario(id);
    }

    @Override
    public Usuarios buscarUsuario(int id) {
        return usuarioService.buscarUsuario(id);
    }

    @Override
    public void removerLivro(int id) {
        livroService.removerLivro(id);
    }

    @Override
    public Livros buscarLivro(int id) {
        return livroService.buscarLivro(id);
    }

    @Override
    public void realizarEmprestimo(Emprestimos emprestimo) {
        emprestimoService.realizarEmprestimo(emprestimo);
    }

    @Override
    public void devolverEmprestimo(int id) {
        emprestimoService.devolverEmprestimo(id);
    }

    @Override
    public Emprestimos buscarEmprestimo(int id) {
        return emprestimoService.buscarEmprestimo(id);
    }
}
