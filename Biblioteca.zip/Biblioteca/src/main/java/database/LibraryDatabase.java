/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Paulo Henrique
 */
public class LibraryDatabase {
    private MySQLConnector connector;

    public LibraryDatabase() {
        this.connector = new MySQLConnector();
    }

    public Connection connect() {
        Connection connection = connector.getConnection();
        if (connection != null) {
            System.out.println("Conexão com BD Biblioteca bem-sucedida usando MySQL!");
        }
        return connection;
    }
    
    public void limparTabelas() {
        System.out.println("Limpando tabelas de dados...");
        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 0");
            stmt.executeUpdate("TRUNCATE TABLE emprestimos");
            stmt.executeUpdate("TRUNCATE TABLE livros");
            stmt.executeUpdate("TRUNCATE TABLE usuarios");
            stmt.executeUpdate("SET FOREIGN_KEY_CHECKS = 1");
            System.out.println("Tabelas limpas com sucesso.");
        } catch (SQLException e) {
            System.err.println("Erro ao limpar tabelas: " + e.getMessage());
        }
    }
    
    // Métodos para interagir com o banco de dados (ex: inserir, selecionar, atualizar)
    // Estes métodos usariam o objeto `Connection` para executar comandos SQL
}
