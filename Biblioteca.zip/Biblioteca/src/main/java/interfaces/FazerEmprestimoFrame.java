/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import executable.LibrarySystem2;
import entities.Emprestimos;

public class FazerEmprestimoFrame extends JFrame {
    private LibrarySystem2 librarySystem;
    private JTextField txtIdLivro, txtIdUsuario, txtIdEmprestimo;
    private JButton btnEmprestar, btnDevolver;

    public FazerEmprestimoFrame(LibrarySystem2 system) {
        this.librarySystem = system;
        setTitle("Fazer Empréstimo");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Campos de empréstimo
        add(new JLabel("ID do Livro:"));
        txtIdLivro = new JTextField(20);
        add(txtIdLivro);

        add(new JLabel("ID do Usuário:"));
        txtIdUsuario = new JTextField(20);
        add(txtIdUsuario);

        btnEmprestar = new JButton("Realizar Empréstimo");
        add(btnEmprestar);

        // Campos de devolução
        add(Box.createVerticalStrut(15));
        add(new JLabel("ID do Empréstimo:"));
        txtIdEmprestimo = new JTextField(20);
        add(txtIdEmprestimo);

        btnDevolver = new JButton("Devolver Empréstimo");
        add(btnDevolver);

        // Lógica dos botões
        btnEmprestar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idLivro = Integer.parseInt(txtIdLivro.getText());
                    int idUsuario = Integer.parseInt(txtIdUsuario.getText());
                    Emprestimos novoEmprestimo = new Emprestimos(idLivro, idUsuario);
                    librarySystem.realizarEmprestimo(novoEmprestimo);
                    JOptionPane.showMessageDialog(null, "Empréstimo realizado com sucesso!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, insira IDs válidos.");
                }
            }
        });

        btnDevolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int idEmprestimo = Integer.parseInt(txtIdEmprestimo.getText());
                    librarySystem.devolverEmprestimo(idEmprestimo);
                    JOptionPane.showMessageDialog(null, "Empréstimo devolvido com sucesso!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, insira um ID de empréstimo válido.");
                }
            }
        });
    }
}
