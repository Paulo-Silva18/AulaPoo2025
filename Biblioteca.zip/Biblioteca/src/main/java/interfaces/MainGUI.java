/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import database.LibraryDatabase;
import executable.LibrarySystem2;

public class MainGUI extends JFrame {
    private JButton btnGerenciarUsuario, btnGerenciarLivro, btnFazerEmprestimo;
    private LibrarySystem2 librarySystem;

    public MainGUI() {
        // Conecta ao banco de dados e instancia o sistema
        LibraryDatabase db = new LibraryDatabase();
        db.connect();
        this.librarySystem = new LibrarySystem2();

        setTitle("Sistema de Gerenciamento de Biblioteca");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Botões para abrir as janelas de gerenciamento
        btnGerenciarUsuario = new JButton("Gerenciar Usuários");
        btnGerenciarLivro = new JButton("Gerenciar Livros");
        btnFazerEmprestimo = new JButton("Fazer Empréstimo");

        add(btnGerenciarUsuario);
        add(btnGerenciarLivro);
        add(btnFazerEmprestimo);

        // Lógica dos botões
        btnGerenciarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GerenciarUsuarioFrame frame = new GerenciarUsuarioFrame(librarySystem);
                frame.setVisible(true);
            }
        });

        btnGerenciarLivro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GerenciarLivroFrame frame = new GerenciarLivroFrame(librarySystem);
                frame.setVisible(true);
            }
        });

        btnFazerEmprestimo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FazerEmprestimoFrame frame = new FazerEmprestimoFrame(librarySystem);
                frame.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainGUI().setVisible(true);
            }
        });
    }
}