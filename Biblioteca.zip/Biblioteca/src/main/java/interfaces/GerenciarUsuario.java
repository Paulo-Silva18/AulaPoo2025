/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import entities.Usuarios;

public interface GerenciarUsuario {
    int adicionarUsuario(Usuarios usuario);
    void removerUsuario(int id);
    Usuarios buscarUsuario(int id);
}
