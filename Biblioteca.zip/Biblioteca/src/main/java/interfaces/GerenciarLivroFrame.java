/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import executable.LibrarySystem2;
import entities.Livros;

public class GerenciarLivroFrame extends JFrame {
    private LibrarySystem2 librarySystem;
    private JTextField txtTitulo, txtAutor, txtAnoPublicacao, txtId;
    private JButton btnAdicionar, btnBuscar;

    public GerenciarLivroFrame(LibrarySystem2 system) {
        this.librarySystem = system;
        setTitle("Gerenciar Livros");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Campos de entrada
        add(new JLabel("Título:"));
        txtTitulo = new JTextField(20);
        add(txtTitulo);

        add(new JLabel("Autor:"));
        txtAutor = new JTextField(20);
        add(txtAutor);

        add(new JLabel("Ano de Publicação:"));
        txtAnoPublicacao = new JTextField(20);
        add(txtAnoPublicacao);

        btnAdicionar = new JButton("Adicionar Livro");
        add(btnAdicionar);
        
        // Campos de busca
        add(Box.createVerticalStrut(15));
        add(new JLabel("Buscar por ID:"));
        txtId = new JTextField(20);
        add(txtId);

        btnBuscar = new JButton("Buscar Livro");
        add(btnBuscar);

        // Lógica dos botões
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String titulo = txtTitulo.getText();
                    String autor = txtAutor.getText();
                    int ano = Integer.parseInt(txtAnoPublicacao.getText());
                    if (!titulo.isEmpty() && !autor.isEmpty()) {
                        Livros novoLivro = new Livros(0, titulo, autor, ano);
                        int idGerado = librarySystem.adicionarLivro(novoLivro);
                        JOptionPane.showMessageDialog(null, "Livro adicionado com ID: " + idGerado);
                    } else {
                        JOptionPane.showMessageDialog(null, "Preencha todos os campos.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, insira um ano válido.");
                }
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(txtId.getText());
                    Livros livroEncontrado = librarySystem.buscarLivro(id);
                    if (livroEncontrado != null) {
                        JOptionPane.showMessageDialog(null, "Livro Encontrado:\nID: " + livroEncontrado.getId() + "\nTítulo: " + livroEncontrado.getTitulo() + "\nAutor: " + livroEncontrado.getAutor());
                    } else {
                        JOptionPane.showMessageDialog(null, "Livro não encontrado.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, insira um ID válido.");
                }
            }
        });
    }
}
