/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package interfaces;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import executable.LibrarySystem2;
import entities.Usuarios;

public class GerenciarUsuarioFrame extends JFrame {
    private LibrarySystem2 librarySystem;
    private JTextField txtNome, txtEmail, txtId;
    private JButton btnAdicionar, btnBuscar;

    public GerenciarUsuarioFrame(LibrarySystem2 system) {
        this.librarySystem = system;
        setTitle("Gerenciar Usuários");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        
        // Campos de entrada
        add(new JLabel("Nome:"));
        txtNome = new JTextField(20);
        add(txtNome);
        
        add(new JLabel("Email:"));
        txtEmail = new JTextField(20);
        add(txtEmail);
        
        btnAdicionar = new JButton("Adicionar Usuário");
        add(btnAdicionar);

        // Campos de busca
        add(Box.createVerticalStrut(15));
        add(new JLabel("Buscar por ID:"));
        txtId = new JTextField(20);
        add(txtId);
        
        btnBuscar = new JButton("Buscar Usuário");
        add(btnBuscar);

        // Lógica dos botões
        btnAdicionar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = txtNome.getText();
                String email = txtEmail.getText();
                if (!nome.isEmpty() && !email.isEmpty()) {
                    Usuarios novoUsuario = new Usuarios(0, nome, email);
                    int idGerado = librarySystem.adicionarUsuario(novoUsuario);
                    JOptionPane.showMessageDialog(null, "Usuário adicionado com ID: " + idGerado);
                } else {
                    JOptionPane.showMessageDialog(null, "Preencha todos os campos.");
                }
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(txtId.getText());
                    Usuarios usuarioEncontrado = librarySystem.buscarUsuario(id);
                    if (usuarioEncontrado != null) {
                        JOptionPane.showMessageDialog(null, "Usuário Encontrado:\nID: " + usuarioEncontrado.getId() + "\nNome: " + usuarioEncontrado.getNome() + "\nEmail: " + usuarioEncontrado.getEmail());
                    } else {
                        JOptionPane.showMessageDialog(null, "Usuário não encontrado.");
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Por favor, insira um ID válido.");
                }
            }
        });
    }
}
