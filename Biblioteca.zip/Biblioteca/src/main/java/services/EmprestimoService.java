// Local: src/main/java/com/library/services/EmprestimoService.java

package services;

import database.LibraryDatabase;
import entities.Emprestimos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

public class EmprestimoService {
    private LibraryDatabase db;
    private LivroService livroService;

    public EmprestimoService() {
        this.db = new LibraryDatabase();
        this.livroService = new LivroService();
    }

    public void realizarEmprestimo(Emprestimos emprestimo) {
        String sql = "INSERT INTO emprestimos (id_livro, id_usuario, data_emprestimo) VALUES (?, ?, ?)";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, emprestimo.getIdLivro());
            pstmt.setInt(2, emprestimo.getIdUsuario());
            pstmt.setDate(3, new Date(System.currentTimeMillis()));

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Empréstimo realizado e salvo no banco de dados!");
                livroService.atualizarDisponibilidade(emprestimo.getIdLivro(), false);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Emprestimos buscarEmprestimo(int id) {
        String sql = "SELECT id, id_livro, id_usuario FROM emprestimos WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                int idLivro = rs.getInt("id_livro");
                int idUsuario = rs.getInt("id_usuario");
                return new Emprestimos(id, idLivro, idUsuario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void devolverEmprestimo(int id) {
        // Esta é a parte que registra a data de devolução e o status
        String sql = "UPDATE emprestimos SET data_devolucao = ?, status = 'Devolvido' WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setDate(1, new Date(System.currentTimeMillis()));
            pstmt.setInt(2, id);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Empréstimo com ID " + id + " marcado como devolvido no banco de dados!");
                
                Emprestimos emprestimo = this.buscarEmprestimo(id);
                if (emprestimo != null) {
                    livroService.atualizarDisponibilidade(emprestimo.getIdLivro(), true);
                    System.out.println("Status do livro com ID " + emprestimo.getIdLivro() + " atualizado para 'disponível'.");
                }
            } else {
                System.out.println("Nenhum empréstimo encontrado com o ID " + id + ".");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}