// Local: src/main/java/com/library/services/LivroService.java

package services;

import database.LibraryDatabase;
import entities.Livros;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LivroService {
    private LibraryDatabase db;

    public LivroService() {
        this.db = new LibraryDatabase();
    }

    public int adicionarLivro(Livros livro) {
        // Altera o SQL para incluir 'ano_publicacao'
        String sql = "INSERT INTO livros (titulo, autor, ano_publicacao) VALUES (?, ?, ?)";
        int generatedId = -1;
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, livro.getTitulo());
            pstmt.setString(2, livro.getAutor());
            pstmt.setInt(3, livro.getAnoPublicacao()); // Adiciona o ano de publicação

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Livro '" + livro.getTitulo() + "' salvo no banco de dados!");
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedId = rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return generatedId;
    }

    public Livros buscarLivro(int id) {
        // Altera o SQL para incluir 'ano_publicacao' na busca
        String sql = "SELECT id, titulo, autor, ano_publicacao FROM livros WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String titulo = rs.getString("titulo");
                String autor = rs.getString("autor");
                int anoPublicacao = rs.getInt("ano_publicacao"); // Obtém o ano de publicação
                return new Livros(id, titulo, autor, anoPublicacao); // Passa o ano para o construtor
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // --- LÓGICA DE REMOÇÃO ---
    public void removerLivro(int id) {
        String sql = "DELETE FROM livros WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Livro com ID " + id + " removido do banco de dados!");
            } else {
                System.out.println("Nenhum livro encontrado com o ID " + id + ".");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Método auxiliar para atualizar o status de disponibilidade do livro
    public void atualizarDisponibilidade(int id, boolean disponivel) {
        String sql = "UPDATE livros SET disponivel = ? WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setBoolean(1, disponivel);
            pstmt.setInt(2, id);
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}