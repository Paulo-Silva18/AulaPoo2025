/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package services;

import database.LibraryDatabase;
import entities.Usuarios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UsuarioService {
    private LibraryDatabase db;

    public UsuarioService() {
        this.db = new LibraryDatabase();
    }

    public int adicionarUsuario(Usuarios usuario) {
        String sql = "INSERT INTO usuarios (nome, email) VALUES (?, ?)";
        int generatedId = -1;
        try (Connection conn = db.connect();
             // Use Statement.RETURN_GENERATED_KEYS para obter o ID gerado
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, usuario.getNome());
            pstmt.setString(2, usuario.getEmail());
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Usuário " + usuario.getNome() + " salvo no banco de dados!");
                
                // Obtenha o ID gerado e retorne-o
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        generatedId = rs.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return generatedId;
    }

    public Usuarios buscarUsuario(int id) {
        String sql = "SELECT id, nome, email FROM usuarios WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                String nome = rs.getString("nome");
                String email = rs.getString("email");
                return new Usuarios(id, nome, email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // --- LÓGICA DE REMOÇÃO ---
    public void removerUsuario(int id) {
        String sql = "DELETE FROM usuarios WHERE id = ?";
        try (Connection conn = db.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Usuário com ID " + id + " removido do banco de dados!");
            } else {
                System.out.println("Nenhum usuário encontrado com o ID " + id + ".");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}