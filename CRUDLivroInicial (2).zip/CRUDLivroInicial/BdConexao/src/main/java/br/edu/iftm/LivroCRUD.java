package br.edu.iftm;

import br.edu.iftm.service.LivroService;
import br.edu.iftm.model.Livro;
import br.edu.iftm.DAO.LivroDAO;
import java.util.List;
import java.util.Scanner;

public class LivroCRUD {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LivroDAO livroDAO = new LivroDAO();
        LivroService livroService = new LivroService();

        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Inserir um novo livro");
            System.out.println("2. Buscar um livro por ID");
            System.out.println("3. Listar todos os livros");
            System.out.println("4. Atualizar um livro");
            System.out.println("5. Excluir um livro");
            System.out.println("0. Sair");
            System.out.print("Digite a opção desejada: ");

            opcao = scanner.nextInt();

            switch (opcao) {
                case 1 -> {
                    Livro novoLivro = coletarDadosLivro();
                    livroService.inserirLivro(novoLivro);
                    System.out.println("Livro inserido com sucesso!");
                }

                case 2 -> {
                    System.out.println("\nBuscando um livro por ID:");
                    System.out.print("Digite id do livro: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    Livro livro = livroService.buscarLivroPorId(id);
                    if (livro != null) {
                        System.out.println(livro);
                    }
                }

                case 3 -> {
                    System.out.println("\nListando todos os livros:");
                    List<Livro> livros;
                    livros = livroDAO.listarTodos();
                    for (Livro livro : livros) {
                        System.out.println(livro);
                    }

                }
                case 4 -> // Atualizar um livro
                    System.out.println("\nAtualizando um livro:");
                // ... (código para solicitar o ID e as novas informações, chamar livroDAO.atualizar())
                case 5 -> {
                    System.out.println("\nExcluindo um livro:");

                }
                case 0 -> {
                    scanner.close();
                    System.out.println("Saindo...");
                }
                default ->
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);
    }

    private static Livro coletarDadosLivro() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nInserindo um novo livro:");
        scanner.nextLine();

        System.out.print("Digite o título do livro: ");
        String titulo = scanner.nextLine();

        System.out.print("Digite o nome do autor: ");
        String autor = scanner.nextLine();

        System.out.print("Digite o ano de publicação: ");
        int anoPublicacao = scanner.nextInt();
        scanner.nextLine(); // Consumir a nova linha

        System.out.print("Digite o ISBN: ");
        String isbn = scanner.nextLine();

        System.out.print("Digite o número de páginas: ");
        int numeroPaginas = scanner.nextInt();
        scanner.nextLine(); // Consumir a nova linha

        Livro novoLivro = new Livro();
        novoLivro.setTitulo(titulo);
        novoLivro.setAutor(autor);
        novoLivro.setAnoPublicacao(anoPublicacao);
        novoLivro.setIsbn(isbn);
        novoLivro.setNumeroPaginas(numeroPaginas);

        return novoLivro;
    }
}
