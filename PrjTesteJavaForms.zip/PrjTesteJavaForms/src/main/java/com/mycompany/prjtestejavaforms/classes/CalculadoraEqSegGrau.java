/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjtestejavaforms.classes;

import com.mycompany.prjtestejavaforms.objetos.DadosEntradaEqSegGrau;
import com.mycompany.prjtestejavaforms.objetos.DadosSaidaEqSegGrau;

/**
 *
 * @author IFTM
 */
public class CalculadoraEqSegGrau {
    public void calcularDelta(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds){
        ds.setDelta(de.getB()*de.getB() - 4*de.getA()*de.getC());
        
    }
    
    public void calcularXLinha(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds) {
        ds.setX1L((float) ((-de.getB() + Math.sqrt(ds.getDelta())) / (2 * de.getA())));
    }
    
    public void calcularX2Linha(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds) {
        ds.setX2L((float) ((-de.getB() - Math.sqrt(ds.getDelta())) / (2 * de.getA())));
    }
    
    public void calcularXV(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds) {
        ds.setxV(-de.getB() / (2 * de.getA()));
    }
    
    public void calcularYV(DadosEntradaEqSegGrau de, DadosSaidaEqSegGrau ds) {
        ds.setyV(-ds.getDelta()/ (4 * de.getA()));
    }
}
