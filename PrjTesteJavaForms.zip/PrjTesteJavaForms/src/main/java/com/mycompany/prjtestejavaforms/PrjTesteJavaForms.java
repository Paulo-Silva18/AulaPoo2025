/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prjtestejavaforms;

import com.mycompany.prjtestejavaforms.forms.FormCalculadora;

/**
 *
 * @author IFTM
 */
public class PrjTesteJavaForms {

    public static void main(String[] args) {
        new FormCalculadora().setVisible(true);
    }
}
