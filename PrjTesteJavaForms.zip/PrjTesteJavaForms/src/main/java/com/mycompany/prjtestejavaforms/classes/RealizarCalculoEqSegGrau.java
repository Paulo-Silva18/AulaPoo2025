/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjtestejavaforms.classes;

import com.mycompany.prjtestejavaforms.objetos.DadosEntradaEqSegGrau;
import com.mycompany.prjtestejavaforms.objetos.DadosSaidaEqSegGrau;
import javax.swing.JOptionPane;

/**
 *
 * @author IFTM
 */
public class RealizarCalculoEqSegGrau {
    
    public DadosSaidaEqSegGrau realizarCalculo(DadosEntradaEqSegGrau de ){
        CalculadoraEqSegGrau calcSegGrau = new CalculadoraEqSegGrau();
        DadosSaidaEqSegGrau ds = new DadosSaidaEqSegGrau();
        
        calcSegGrau.calcularDelta(de, ds);
        
        if(ds.getDelta() < 0) {
            JOptionPane.showMessageDialog(null, "Delta menor que zero. Não há raizes reais");
        }
        else {
            calcSegGrau.calcularXLinha(de, ds);
            calcSegGrau.calcularX2Linha(de, ds);
        }
        calcSegGrau.calcularXV(de, ds);
        calcSegGrau.calcularYV(de, ds);
        
        return ds;
    }
    
}
