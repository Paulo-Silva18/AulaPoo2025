/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prjtestejavaforms.classes;

/**
 *
 * @author IFTM
 */
public class Calculadora {
    public Float somar(float nro1, float nro2){
        return nro1 + nro2;
    }
    
    public Float subtrair(float nro1, float nro2){
        return nro1 - nro2;
    }
    
    public Float multiplicar(float nro1, float nro2){
        return nro1 * nro2;
    }
    
    public Float dividir(float nro1, float nro2){
        return nro1 / nro2;
    }
    
}
