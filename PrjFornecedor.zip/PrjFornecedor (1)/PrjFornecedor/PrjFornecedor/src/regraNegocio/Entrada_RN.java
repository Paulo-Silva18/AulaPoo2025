/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regraNegocio;

import classes_bd.Entrada_BD;
import classes_bd.Produto_BD;
import java.util.List;
import objetos.Entrada;
import objetos.EntradaProduto;
import objetos.Produto;

/**
 *
 * @author Paulo Henrique
 */
public class Entrada_RN {
    Entrada_BD e_BD;
    Produto_BD p_BD;
    public Entrada_RN() {
        e_BD = new Entrada_BD();
        p_BD = new Produto_BD();
    }
    
    public void salvarEntrada(Entrada e) {
        calcularTotalEntrada(e);
        e_BD.salvar(e);
        if (e.getIdentrada() != 0) {
            for (EntradaProduto ep : e.getItens_entrada()) {
                e_BD.salvarEntradaProduto(ep);
            }
        }
    }
    
    private void calcularTotalEntrada(Entrada e) {
        double total = 0;
        for (EntradaProduto ep : e.getItens_entrada()) {
            Produto p = ep.getProdutos();
            p_BD.getProduto(p);
            total += p.getValor() * ep.getQuantidade();
        }
        e.setTotal_entrada(total);
    }
    
    public void mostrarEntradas() {
        List<Entrada> lstE = e_BD.getEntradas();
        mostrarEntradas(lstE);
    }
    
    private void mostrarEntradas(List<Entrada> entradas) {
        for (Entrada entrada : entradas) {
            System.out.println("ID: " + entrada.getIdentrada());
            System.out.println("Data da entrada: " + entrada.getData_entrada());
            System.out.println("Total da entrada: " + entrada.getTotal_entrada());
            System.out.println("Fornecedor: " + entrada.getFornecedor().getNome());
            if (entrada.getItens_entrada() != null) {
                System.out.println("\n");
                mostrarItens(entrada.getItens_entrada());
            }
        }
    }
    
    private void mostrarItens(List<EntradaProduto> lstEP) {
        for (EntradaProduto ep : lstEP) {
            System.out.println("ID Entrada: " + ep.getEntrada().getIdentrada());
            System.out.println("ID Produto: " + ep.getProdutos().getIdProduto());
            System.out.println("Produto: " + ep.getProdutos().getNome());
            System.out.println("Valor: " + ep.getProdutos().getValor());
            System.out.println("Quantidade: " + ep.getQuantidade());
            System.out.println("\n");
        }
    }
    
}
