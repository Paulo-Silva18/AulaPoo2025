/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import objetos.Contato;
import objetos.Fornecedor;
import regraNegocio.Fornecedor_RN;

/**
 *
 * @author Paulo Henrique
 */
public class CRUD_Fornecedor {
    public static void executar(Scanner scanner) {
        Fornecedor_RN fornecedorRN = new Fornecedor_RN();
        int opcao;
        
        do {
            System.out.println("==== MENU FORNECEDOR/CONTATO ====");
            System.out.println("1 - Cadastrar Fornecedor");
            System.out.println("2 - Listar Fornecedores");
            System.out.println("0 - Voltar");
            System.out.println("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); //limpar buffer
            
            switch (opcao) {
                case 1 -> {
                    Fornecedor f = new Fornecedor();
                    System.out.println("Nome: ");
                    f.setNome(scanner.nextLine());
                    System.out.println("CNPJ: ");
                    f.setCnpj(scanner.nextLine());
                    
                    List<Contato> contatos = new ArrayList<>();
                    System.out.println("Quantos contatos deseja adicionar? ");
                   int qtd = scanner.nextInt();
                   scanner.nextLine();
                   
                   for (int i = 0; i < qtd; i++) {
                       Contato c = new Contato();
                       System.out.println("Tipo do contato: ");
                       c.setTipo_contato(scanner.nextLine());
                       System.out.println("Contato");
                       c.setContato(scanner.nextLine());
                       c.setFornecedor(f);
                       contatos.add(c);
                   }
                   
                   f.setContatos(contatos);
                   fornecedorRN.salvarFornecedor(f);
                }
                case 2 -> fornecedorRN.mostrarFornecedores();
                case 0 -> System.out.println("Voltanto ao menu principal...");
                default -> System.out.println("Opção inválida");
                
            }
        } while (opcao != 0);
    } 
   
}
