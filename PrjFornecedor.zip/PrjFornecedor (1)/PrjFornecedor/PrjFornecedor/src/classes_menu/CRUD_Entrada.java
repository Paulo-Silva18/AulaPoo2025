/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import objetos.Entrada;
import objetos.EntradaProduto;
import objetos.Fornecedor;
import objetos.Produto;
import regraNegocio.Entrada_RN;

/**
 *
 * @author IFTM
 */
public class CRUD_Entrada {
    public static void executar(Scanner scanner) {
        Entrada_RN entradaRN = new Entrada_RN();
        int opcao;
        
        do {
            System.out.println("=== MENU ENTRADA ===");
            System.out.println("1 - Registrar Entrada");
            System.out.println("2 - Listar Entradas");
            System.out.println("0 - Voltar");
            System.out.println("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();
            
            switch (opcao) {
                case 1 -> {
                    Entrada e = new Entrada();
                    
                    Fornecedor f = new Fornecedor();
                    System.out.println("ID do fornecedor: ");
                    f.setId_fornecedor(scanner.nextInt());
                    scanner.nextLine();
                    e.setFornecedor(f);
                    
                    System.out.println("Data: ");
                    e.setData_entrada(scanner.nextLine());
                    
                    List<EntradaProduto> itens = new ArrayList<>();
                    
                    System.out.println("Quantos produtos na entrada? ");
                    int qtd = scanner.nextInt();
                    scanner.nextLine();
                    
                    for(int i = 0; i < qtd; i++) {
                        EntradaProduto ep = new EntradaProduto();
                        Produto p = new Produto();
                        System.out.println("ID do produto: ");
                        p.setIdProduto(scanner.nextInt());
                        scanner.nextLine();
                        ep.setProdutos(p);
                        
                        System.out.println("Quantidade: ");
                        ep.setQuantidade(scanner.nextInt());
                        scanner.nextLine();
                        
                        ep.setEntrada(e);
                        itens.add(ep);
                    }
                    e.setItens_entrada(itens);
                    entradaRN.salvarEntrada(e);
                }
                case 2 -> entradaRN.mostrarEntradas();
                case 0 -> System.out.println("Voltando ao menu principal...");
                default -> System.out.println("opção inválida");
            }
        } while (opcao != 0);
    }
    
}
