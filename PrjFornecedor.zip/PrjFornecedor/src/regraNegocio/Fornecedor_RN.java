/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regraNegocio;

import classes_bd.Contato_BD;
import classes_bd.Fornecedor_BD;
import java.util.List;
import objetos.Contato;
import objetos.Fornecedor;

/**
 *
 * @author IFTM
 */
public class Fornecedor_RN {
    
    Fornecedor_BD f_BD;
    Contato_BD c_BD;
    public Fornecedor_RN() {
        f_BD = new Fornecedor_BD();
        c_BD = new Contato_BD();
    }
    
    public void salvarFornecedor(Fornecedor f) {
        if (f.getContatos() != null && !f.getContatos().isEmpty()) {
            f_BD.salvar(f);
            
            for (Contato c : f.getContatos()) {
                c_BD.salvar(c);
            }
        }
        else {
            f_BD.salvar(f);
        }
    }
    
    public void mostrarFornecedores() {
        List<Fornecedor> lstF = f_BD.getFornecedores_Contatos();
        mostrarFornecedores(lstF);
    }
    
    public void mostrarFornecedores (List<Fornecedor> fornecedores) {
        for (Fornecedor fornecedor : fornecedores) {
            System.out.println("ID: " + fornecedor.getId_fornecedor());
            System.out.println("Nome: " + fornecedor.getNome());
            System.out.println("CNPJ: " + fornecedor.getCnpj());
            System.out.println("\n\n");
        }
    }
    
    public void mostrarContatos (List<Contato> contatos) {
        for (Contato contato : contatos) {
            System.out.println("ID: " + contato.getId_contato());
            System.out.println("Tipo: " + contato.getTipo_contato());
            System.out.println("Contato: " + contato.getContato());
            System.out.println("ID Fornecedor: " + contato.getFornecedor().getId_fornecedor());
            System.out.println("\n");
        }
    }
    
}
