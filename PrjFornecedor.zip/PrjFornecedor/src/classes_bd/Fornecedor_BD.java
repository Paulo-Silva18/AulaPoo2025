/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import objetos.Fornecedor;
import util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Contato;



/**
 *
 * @author IFTM
 */
public class Fornecedor_BD {
    Connection conn;
    Contato_BD c_BD;
    
    public Fornecedor_BD() {
        conn = new Conexao().conectar();
        c_BD = new Contato_BD();
    }
    public Fornecedor salvar(Fornecedor f) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO Fornecedor(nome, cnpj) values(?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, f.getNome());
            stmt.setString(2, f.getCnpj());
            stmt.execute();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return f;
    }
    
    public List<Fornecedor> getFornecedores() throws SQLException {
        List<Fornecedor> lstF = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Fornecedor");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstF.add(getFornecedor(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstF;
    }
    
    public List<Fornecedor> getFornecedores_Contatos() {
        List<Fornecedor> lstF = new ArrayList<>();
        List<Contato> lstC = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM Fornecedor LEFT JOIN contato ON Fornecedor.id = contato.id_fornecedor");
            rs = ppStmt.executeQuery();
            int verif_id = 0;
            while(rs.next()) {
                if (rs.getInt("id_contato") == 0) {
                    lstF.add(getFornecedor(rs));
                }
                else {
                    Fornecedor f = getFornecedor(rs);
                    if (verif_id == f.getId_fornecedor()) {
                        lstC.add(c_BD.getContatos(rs, f));
                        f = lstF.getLast();
                        f.setContatos(lstC);
                    }
                    else {
                        lstC.add(c_BD.getContatos(rs, f));
                        f.setContatos(lstC);
                        lstF.add(f);
                        verif_id = f.getId_fornecedor();
                    }
                }
                
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstF;
    }
    
    public Fornecedor getFornecedor(ResultSet rs) throws SQLException {
        Fornecedor f = new Fornecedor();
        
        f.setId_fornecedor(rs.getInt("id"));
        f.setNome(rs.getString("nome"));
        f.setCnpj(rs.getString("cnpj"));
        return f;
    }
    
}
