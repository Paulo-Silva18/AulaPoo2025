/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Entrada;
import objetos.EntradaProduto;
import objetos.Fornecedor;
import objetos.Produto;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Entrada_BD {
    Connection conn;
    
    public Entrada_BD() {
        conn = new Conexao().conectar();
    }
    public Entrada salvar(Entrada e) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO entrada(data_entrada, total_entrada, idfornecedor) values(?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, e.getData_entrada());
            stmt.setDouble(2, e.getTotal_entrada());
            stmt.setInt(3, e.getFornecedor().getId_fornecedor());
            int verif = stmt.executeUpdate();
            if (verif > 0) {
                ResultSet rs_id = stmt.getGeneratedKeys();
                if(rs_id.next()) {
                    e.setIdentrada(rs_id.getInt(1));
                }
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return e;
    }
    public EntradaProduto salvarEntradaProduto(EntradaProduto ep) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO entrada_produto(identrada, idproduto, quantidade) values(?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, ep.getEntrada().getIdentrada());
            stmt.setInt(2, ep.getProdutos().getIdProduto());
            stmt.setInt(3, ep.getQuantidade());
            int verif = stmt.executeUpdate();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return ep;
    }
    public List<Entrada> getEntradas() {
        List<Entrada> lstE = new ArrayList<>();
        List<EntradaProduto> lstEP = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM fornecedor f, entrada e, entrada_produto ep, produto p WHERE f.idfornecedor = e.idfornecedor AND e.identrada = ep.identrada AND ep.idProduto = p.idProduto");
            rs = stmt.executeQuery();
            int verif_id = 0;
            while (rs.next()) {
                Entrada e = getEntrada(rs);
                if (verif_id == e.getIdentrada()) {
                    lstEP.add(getItens(rs, e));
                    e = lstE.getLast();
                    e.setItens_entrada(lstEP);
                }
                else {
                    lstEP = new ArrayList<>();
                    lstEP.add(getItens(rs, e));
                    e.setItens_entrada(lstEP);
                    lstE.add(e);
                    verif_id = e.getIdentrada();
                }
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstE;
    }
    public Entrada getEntrada(ResultSet rs) throws SQLException {
        Entrada e = new Entrada();
        Fornecedor f = new Fornecedor();
        
        e.setIdentrada(rs.getInt("identrada"));
        e.setData_entrada(rs.getString("data_entrada"));
        e.setTotal_entrada(rs.getDouble("total_entrada"));
        
        f.setId_fornecedor(rs.getInt("idfornecedor"));
        f.setNome(rs.getString("nome"));
        f.setCnpj(rs.getString("cnpj"));
        
        e.setFornecedor(f);
        return e;
    }
    
    public EntradaProduto getItens(ResultSet rs, Entrada e) throws SQLException {
        EntradaProduto ep = new EntradaProduto();
        Produto p = new Produto();
        
        p.setIdProduto(rs.getInt("idproduto"));
        p.setNome(rs.getString("nome"));
        p.setValor(rs.getDouble("valor"));
        
        ep.setQuantidade(rs.getInt("quantidade"));
        ep.setProdutos(p);
        if(e != null) {
            ep.setEntrada(e);
        }
        return ep;
    }
}
