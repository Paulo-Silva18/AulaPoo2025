/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes_bd;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import objetos.Contato;
import objetos.Entrada;
import objetos.Produto;
import util.Conexao;

/**
 *
 * @author Paulo Henrique
 */
public class Produto_BD {
    Connection conn;
    
    public Produto_BD() {
        conn = new Conexao().conectar();
    }
    public Produto salvar(Produto p) {
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO entrada(idProduto, nome, valor) values(?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, p.getIdProduto());
            stmt.setString(2, p.getNome());
            stmt.setDouble(3, p.getValor());
            int verif = stmt.executeUpdate();
            if (verif > 0) {
                ResultSet rs_id = stmt.getGeneratedKeys();
                if(rs_id.next()) {
                    p.setIdProduto(rs_id.getInt(1));
                }
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return p;
    }
    
    public List<Produto> getProdutos() {
        List<Produto> lstP = new ArrayList<>();
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM produto");
            rs = ppStmt.executeQuery();
            while(rs.next()) {
                lstP.add(getProduto(rs));
            }
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return lstP;
        }
    
    public Produto getProduto(Produto p) {
        ResultSet rs;
        try {
            PreparedStatement ppStmt = conn.prepareStatement("SELECT * FROM produto WHERE idproduto = ?");
            ppStmt.setInt(1, p.getIdProduto());
            rs = ppStmt.executeQuery();
            rs.next();
            p.setNome(rs.getString("nome"));
            p.setValor(rs.getDouble("valor"));
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
        return p;
    }
    
    private Produto getProduto(ResultSet rs) throws SQLException {
        Produto p = new Produto();
        
        p.setIdProduto(rs.getInt("id"));
        p.setNome(rs.getString("nome"));
        p.setValor(rs.getDouble("valor"));
        return p;
    }
}
