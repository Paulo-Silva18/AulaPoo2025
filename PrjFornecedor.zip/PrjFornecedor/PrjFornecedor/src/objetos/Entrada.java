/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objetos;

import java.util.List;

/**
 *
 * @author Paulo Henrique
 */
public class Entrada {
    private int identrada;
    private String data_entrada;
    private Fornecedor fornecedor;
    private double total_entrada;
    private List<EntradaProduto> itens_entrada;
    

    public int getIdentrada() {
        return identrada;
    }

    public void setIdentrada(int identrada) {
        this.identrada = identrada;
    }

    public String getData_entrada() {
        return data_entrada;
    }

    public void setData_entrada(String data_entrada) {
        this.data_entrada = data_entrada;
    }

    public Fornecedor getFornecedor() {
        return fornecedor;
    }

    public void setFornecedor(Fornecedor fornecedor) {
        this.fornecedor = fornecedor;
    }

    public double getTotal_entrada() {
        return total_entrada;
    }

    public void setTotal_entrada(double total_entrada) {
        this.total_entrada = total_entrada;
    }

    public List<EntradaProduto> getItens_entrada() {
        return itens_entrada;
    }

    public void setItens_entrada(List<EntradaProduto> itens_entrada) {
        this.itens_entrada = itens_entrada;
    }
    
    
}
