/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package regraNegocio;

import classes_bd.Produto_BD;
import java.util.List;
import objetos.Produto;

/**
 *
 * @author Paulo Henrique
 */
public class Produto_RN {
    Produto_BD p_BD;
    public Produto_RN() {
        p_BD = new Produto_BD();
    }
    public void salvarProduto(Produto p) {
        p_BD.salvar(p);
    }
    public void mostrarProdutos() {
        List<Produto> produtos = p_BD.getProdutos();
        for (Produto produto : produtos) {
            System.out.println("ID: " + produto.getIdProduto());
            System.out.println("Nome: " + produto.getNome());
            System.out.println("Valor: " + produto.getValor());
            System.out.println("\n");
        }
    }
    
}
